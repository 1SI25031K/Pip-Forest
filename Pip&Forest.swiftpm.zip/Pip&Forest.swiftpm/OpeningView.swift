import SwiftUI
import AVFoundation

struct OpeningView: View {
    @State private var showingForestView = false // View の表示状態を管理
    @State private var speechSynthesizer = AVSpeechSynthesizer()
    @State private var isSpeaking = false // 読み上げ中かどうかを管理
    
    class SoundPlayer {
        static let shared = SoundPlayer()
        private var startSound: AVAudioPlayer?
        
        private init() {
            if let startSoundURL = Bundle.main.url(forResource: "Start", withExtension: "m4a") {
                startSound = try? AVAudioPlayer(contentsOf: startSoundURL)
                startSound?.prepareToPlay()
            }
        }
        func playStartSound() {
            startSound?.play()
        }
    }
    
    let synthesizer = AVSpeechSynthesizer() // AVSpeechSynthesizerのインスタンスを作成
    // メッセージを読み上げる関数
    func speakMessage(message: String) {
        let utterance = AVSpeechUtterance(string: message)
        
        utterance.pitchMultiplier = 1.5
        // 読み上げ速度を遅くする (例: 0.4倍)
        utterance.rate = AVSpeechUtteranceDefaultSpeechRate * 0.8 // デフォルトの速度の 0.8倍
        
       if let voice = AVSpeechSynthesisVoice(identifier: "com.apple.ttsbundle.Samantha-compact"){
            utterance.voice = voice
        } else {
            utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        }
        synthesizer.speak(utterance)
    }
    
    var body: some View {
        NavigationStack {
            ScrollView(.vertical){
                VStack{
                    Text("Forests have important roles.")
                        .font(.largeTitle)
                        .fontWeight(.heavy)
                        .fontDesign(.serif)
                        .frame(maxWidth: .infinity)
                        .padding(60)
                        .padding(.top, 30)
                        .accessibilityLabel("Forests have important roles.") // VoiceOver用のラベル
                    
                    ForEach(forestRoles) { role in
                        ForestRoleView(forestRole: role, speechSynthesizer: speechSynthesizer)
                    }
                    
                    Text("In a certain forest, there are many trees living in harmony. However, all the trees in the forest are the same kind, and the forest is somewhat listless and boring. Then, from somewhere, you hear a gentle voice:")
                        .font(.title)
                        .fontDesign(.serif)
                        .padding()
                        .background(Color.white.opacity(0.8))
                        .border(.black)
                        .padding(.top,30)
                        .padding(.horizontal)
                        .accessibilityLabel("In a certain forest, there are many trees living in harmony. However, all the trees in the forest are the same kind, and the forest is somewhat listless and boring. Then, from somewhere, you hear a gentle voice:") // VoiceOver用のラベル
                    Button(action: {
                        isSpeaking.toggle() // 読み上げ状態を切り替え
                         speechSynthesizer.stopSpeaking(at: .immediate)
                        if isSpeaking {
                            speak("In a certain forest, there are many trees living in harmony. However, all the trees in the forest are the same kind, and the forest is somewhat listless and boring. Then, from somewhere, you hear a gentle voice:")
                        } else {
                            speechSynthesizer.stopSpeaking(at: .immediate) // 読み上げを停止
                        }
                    }) {
                        Image(systemName: isSpeaking ? "speaker.slash.circle.fill" : "speaker.wave.2.circle.fill") // 読み上げ状態によってアイコンを変更
                            .font(.system(size: 50))
                            .symbolRenderingMode(.palette) // パレットモードを設定
                            .foregroundStyle(isSpeaking ? Color.red : Color.blue, .white.opacity(0.8))
                            .padding()
                            .accessibilityLabel(isSpeaking ? "Stop reading story" : "Read story aloud") // VoiceOver用ラベルを追加：読み上げ状態に応じてラベルを変更
                    }
                    Button(action: {
                        SoundPlayer.shared.playStartSound()
                        showingForestView.toggle()
                    }) {
                        HStack{
                            Image(systemName: "forward.fill")
                             .padding(.horizontal)
                            Text("Next")
                                .padding(.horizontal)
                            Image(systemName: "forward.fill")
                             .padding(.horizontal)
                        }
                                .font(.largeTitle)
                                .padding(.vertical)
                                .padding(.horizontal,80)
                                .foregroundStyle(Color.white)
                                .background(.blue)
                                .cornerRadius(16)
                                .padding(.bottom)
                    } 
                    .padding(40)
                    .padding(.bottom, 10)
                    .navigationDestination(isPresented: $showingForestView) { 
                        ForestView()
                    }
                    .accessibilityLabel("Next") // ボタンのVoiceOverラベル
                    .accessibilityHint("Proceed to the next screen.") // ボタンのVoiceOverヒント
                }
            }
            .preferredColorScheme(.light)
        }
    }
    
    func speak(_ text: String) {
        let utterance = AVSpeechUtterance(string: text)
        
        // 特定の identifier の voice を取得を試みる (Samantha)
        if let samanthaVoice = AVSpeechSynthesisVoice(identifier: "com.apple.ttsbundle.Samantha-compact") {
            // Samantha voice が見つかった場合： utterance に Samantha voice を設定
            utterance.voice = samanthaVoice
        } else {
            // Samantha voice が見つからなかった場合 (Fallback 処理)：
            //    英語 (アメリカ) のデフォルト voice を utterance に設定
            utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        }
        
        utterance.pitchMultiplier = 1.5
        utterance.rate = AVSpeechUtteranceDefaultSpeechRate * 0.8
        
        speechSynthesizer.speak(utterance)
    }
}

struct ForestRole: Identifiable {
    let id = UUID()
    let title: String
    let description: String
    let imageNames: [String] // 画像ファイル名または SF Symbol 名の配列 (画像表示用)
    let emoji: String 
}

let forestRoles = [
    ForestRole(title: "Prevention of disaster", description: "Forest stabilize soil,enabling gradual rainwater absorption, preventing it from collapsing or flooding.", imageNames: [ "Collapsing.Genmoji", "Flooding.Genmoji"], emoji: "💧 🦺"),
    ForestRole(title: "Preservation of environment", description: "Forest absorbs carbon dioxide and pollutants and releases fresh air with oxygen.", imageNames: ["Absorb.Genmoji","Release.Genmoji"], emoji: "🌎"),
    ForestRole(title: "Biodiversity Conservation", description: "Forest provide animals with food, roosting places, and places to hide from enemies.﻿",  imageNames: [], emoji: "🐸 🐵 🐰 🐻")]

struct ForestRoleView: View {
    let forestRole: ForestRole
    let speechSynthesizer: AVSpeechSynthesizer
    @State private var isSpeaking = false // 読み上げ中かどうかを管理
    
    var body: some View {
        VStack(alignment: .center) {
            Text(forestRole.title)
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()
                .accessibilityLabel(forestRole.title) // VoiceOver用のラベル
            
            Text(forestRole.description)
                .font(.title)
                .padding()
                .accessibilityLabel(forestRole.description) // VoiceOver用のラベル
            Button(action: {
                isSpeaking.toggle() // 読み上げ状態を切り替え
                if isSpeaking {
                    speak(forestRole.title + ". " + forestRole.description)
                } else {
                    speechSynthesizer.stopSpeaking(at: .immediate) // 読み上げを停止
                }
            }) {
                Image(systemName: isSpeaking ? "speaker.slash.circle.fill" : "speaker.wave.2.circle.fill") // 読み上げ状態によってアイコンを変更
                    .font(.system(size: 50))
                    .symbolRenderingMode(.palette) // パレットモードを設定
                    .foregroundStyle(isSpeaking ? Color.red : Color.blue, .white.opacity(0.8))
                    .padding()
                    .accessibilityLabel(isSpeaking ? "Stop reading role description" : "Read role description aloud") // VoiceOver用ラベルを追加：読み上げ状態に応じてラベルを変更
            }
            if !forestRole.imageNames.isEmpty { // imageNames が空でない場合 (画像を表示)
                HStack {
                    ForEach(forestRole.imageNames, id: \.self) { imageName in
                        Image(imageName) // SF Symbols を使用
                            .resizable()
                            .scaledToFit()
                            .padding(.horizontal)
                            .frame(width: 220, height: 220)
                    }
                }
                .accessibilityElement(children: .combine)
                .accessibilityLabel("\(forestRole.title) is shown by Genmoji.")
            } else { // imageNames が空の場合 (絵文字テキストを表示)
                Text(forestRole.emoji) // 絵文字テキストを表示
                    .font(.system(size: 140))
                    .accessibilityLabel("\(forestRole.title) is shown by Emoji.: \(forestRole.emoji)")
            }
        }
        .padding() 
        Divider()
    }
    
    func speak(_ text: String) {
        let utterance = AVSpeechUtterance(string: text)
        
        // 特定の identifier の voice を試みる
        if let samanthaVoice = AVSpeechSynthesisVoice(identifier: "com.apple.ttsbundle.Samantha-compact") {
            // Samantha voice が見つかった場合、それを使用する
            utterance.voice = samanthaVoice
        } else {
            // Samantha voice が見つからなかった場合 (Fallback 処理)
            //    デフォルトの英語 (アメリカ) voice を使用する
            utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        }
        
        utterance.pitchMultiplier = 1.5
        utterance.rate = AVSpeechUtteranceDefaultSpeechRate * 0.8
        
        speechSynthesizer.speak(utterance)
    }
}
