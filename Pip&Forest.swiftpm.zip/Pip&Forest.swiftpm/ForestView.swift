import SwiftUI
import AVFoundation
import PencilKit

// サウンドプレーヤークラス
class SoundPlayer {
    static let shared = SoundPlayer()
    private var treeSound: AVAudioPlayer?
    private var niceSound: AVAudioPlayer?
    private var plantSound: AVAudioPlayer?
    private var greatSound: AVAudioPlayer?
    private var mulchingSound: AVAudioPlayer?
    private var excellentSound: AVAudioPlayer?
    private var wonderfulSound: AVAudioPlayer?
    private var animalSound: AVAudioPlayer?
    private var redwoodSound: AVAudioPlayer?
    private var endingSound: AVAudioPlayer?
    private var pipSound: AVAudioPlayer?
    private var isRedwoodPlaying: Bool = false
    private var isRedwoodLooping: Bool = false
    private var isEndingPlaying: Bool = false
    private var isEndingLooping: Bool = false
    
    private init() {
        if let treeSoundURL = Bundle.main.url(forResource: "Cut", withExtension: "m4a") {
            treeSound = try? AVAudioPlayer(contentsOf: treeSoundURL)
            treeSound?.prepareToPlay()
        }
        
        if let niceSoundURL = Bundle.main.url(forResource: "Nice", withExtension: "m4a") {
            niceSound = try? AVAudioPlayer(contentsOf: niceSoundURL)
            niceSound?.prepareToPlay()
        }
        
        if let plantSoundURL = Bundle.main.url(forResource: "Plant", withExtension: "m4a"){
            plantSound = try? AVAudioPlayer(contentsOf: plantSoundURL)
            plantSound?.prepareToPlay()
        }
        
        if let greatSoundURL = Bundle.main.url(forResource: "Great", withExtension: "m4a"){
            greatSound = try? AVAudioPlayer(contentsOf: greatSoundURL)
            greatSound?.prepareToPlay()
        }
        if let mulchingSoundURL = Bundle.main.url(forResource: "Mulching", withExtension: "m4a"){
            mulchingSound = try? AVAudioPlayer(contentsOf: mulchingSoundURL)
            mulchingSound?.prepareToPlay()
        }
        if let excellentSoundURL = Bundle.main.url(forResource: "Excellent", withExtension: "m4a"){
            excellentSound = try? AVAudioPlayer(contentsOf: excellentSoundURL)
            excellentSound?.prepareToPlay()
        }
        if let wonderfulSoundURL = Bundle.main.url(forResource: "Wonderful", withExtension: "m4a"){
            wonderfulSound = try? AVAudioPlayer(contentsOf: wonderfulSoundURL)
            wonderfulSound?.prepareToPlay()
        }
        if let animalSoundURL = Bundle.main.url(forResource: "Animals", withExtension: "m4a"){
            animalSound = try? AVAudioPlayer(contentsOf: animalSoundURL)
            animalSound?.prepareToPlay()
        }
        if let redwoodSoundURL = Bundle.main.url(forResource: "Forest", withExtension: "mp3"){
            redwoodSound = try? AVAudioPlayer(contentsOf: redwoodSoundURL)
            redwoodSound?.prepareToPlay()
        }
        if let endingSoundURL = Bundle.main.url(forResource: "Ending", withExtension: "m4a"){
            endingSound = try? AVAudioPlayer(contentsOf: endingSoundURL)
            endingSound?.prepareToPlay()
        }
        if let pipSoundURL = Bundle.main.url(forResource: "Pip", withExtension: "m4a"){
            pipSound = try? AVAudioPlayer(contentsOf: pipSoundURL)
            pipSound?.prepareToPlay()
        }
    }
    
    func playTreeSound() {
        treeSound?.currentTime = 0
        treeSound?.play()
    }
    
    func playNiceSound() {
        niceSound?.play()
    }
    
    func playPlantSound() {
        plantSound?.currentTime = 0
        plantSound?.play()
    }
    
    func playGreatSound() {
        greatSound?.play()
    }
    func playMulchingSound() {
        mulchingSound?.currentTime = 0
        mulchingSound?.play()
    }
    func playExcellentSound() {
        excellentSound?.play()
    }
    func playWonderfulSound() {
        wonderfulSound?.play()
    }
    func playPipSound() {
        pipSound?.play()
    }
    func playAnimalsSound() {
        animalSound?.currentTime = 0
        animalSound?.play()
    }
    func playRedWoodSound() {
        if isRedwoodLooping {
            redwoodSound?.pause() // または stop()
            isRedwoodLooping = false
        } else {
            redwoodSound?.numberOfLoops = -1 // 無限ループを設定
            redwoodSound?.play()
            isRedwoodLooping = true
        }
    }
    func playEndingSound() {
        endingSound?.play() // または stop()
    }
}

struct ForestView: View {
    @State private var treeStates: [[TreeState]] = [
        Array(repeating: TreeState(), count: 10),
        Array(repeating: TreeState(), count: 7),
        Array(repeating: TreeState(), count: 6),
        Array(repeating: TreeState(), count: 5),
        Array(repeating: TreeState(), count: 4)
    ]
    
    @State private var messageIndex = 0
    @State private var complimentationIndex = 0
    @State private var logCount: Int? = 0
    @State private var showingComplimentations = false
    @State private var isCuttingDisabled = false  // 🌲を切る機能の無効化フラグ
    @State private var showingHowWoodUsed = false
    @State private var plantAppears = false  // 🪴 を表示するフラグ
    @State private var remainingPlants: Int = 6 // 残りの🪴の数
    @State private var isDragging: Bool = false
    @State private var plantPosition: CGPoint? = nil
    @State private var mulchingAppears = false // 🟤を表示するフラグ
    @State private var remainingMulching: Int = 18 // 残りの🟤の数
    @State private var mulchingPosition: CGPoint? = nil
    @State private var sliderAppears = false
    @State private var sliderValue : Double = 0.0
    @State private var hasSliderReachedEnd = false
    @State private var showingFlowers = false 
    @State private var showingBugs = false 
    @State private var showingBirds = false
    @State private var showingAnimals = false
    @State private var showCanvas = false
    @State private var animalButtonsAppears = false
    @State private var showingEndingView = false
    @State private var isListening: Bool = true
    @State private var isDrawingCanvasVisible = true
    @State private var isStorySpoken = false
    
    let gradient = Gradient(stops: [
        .init(color: .blue, location: 0.0),
        .init(color: .brown, location: 0.46),
        .init(color: .brown, location: 1.0)
    ])
    
    @State private var gradient2 = Gradient(stops: [
        .init(color: .clear, location: 0.0),
        .init(color: .black, location: 0.5),
        .init(color: .black.opacity(0.9), location: 0.75),
        .init(color: .black.opacity(0.8), location: 1.0)
    ])
    
    let gradient3 = Gradient(stops: [
        .init(color: .white.opacity(0.6), location: 0.0),
        .init(color: .clear, location: 0.6),
        .init(color: .clear, location: 1.0)
    ])
    
    @State private var gradient4 = Gradient(stops: [
        .init(color: .clear, location: 0.0),
        .init(color: .clear, location: 1.0)
    ])
    
    let messages = [
        "\"Hi there. I'm Pip, the spirit of the forest. You see, this forest is not healthy. So I want to turn it into a forest where there are more trees, grass, flowers, a place where animals can live happily. To do that, I want to reduce the number of trees a little and grow some new ones. Will you help me? First of all, I want you to cut down 12 trees by tapping them.\"",
        "In the forest, the light is getting brighter and brighter. You turn to Pip and say.'Now even the little seedlings look like they'll grow well enough!' Then Pip makes six 🪴 appear in front of you and says,“I'll lend you some magic power, can you swipe the 🪴 in the direction of the arrow?\"",
        "Oh no, the newly planted seedlings are about to be blown away by the wind! Then Pip tells you,\"Swipe this 🟤 to enclose the new seedlings. This is called “mulching” and is a way to protect the seedlings from the wind and rain until they are big enough. The 🟤 will return to nature, so it's good for the forest.\"",
        "\"Did you know that as plants grow, they suck in air that is bad for humans and animals. If you plant lots of trees, they can give us and the living things around us the clean air that we need. Isn't that wonderful?\"",
        "Oh, the little blades of grass and pretty flowers are beginning to show their faces. Butterflies and small birds are happily flying around in the forest.“ The forest is getting better and better!” You,Pip, and the forest creatures are all overjoyed. Now, when all the creatures have gathered together, you can freely draw pictures to make the forest as wonderful as you want it to be!"
    ]
    
    let complimentations = [
        "✨ Nice! ✨",
        "🤩 Great! 🤩",
        "💫 Excellent! 💫",
        "😍 Wonderful! 😍",
        "",
    ]
    
    let flowers = ["four_leaf_clover_3d","shamrock_3d","blossom_3d","rabbit_3d","tulip_3d","brown_mushroom_3d"]
    let bugs = ["worm_3d","snail_3d","lady_beetle_3d","ant_3d","beetle_3d","spider_3d","lizard_3d","bug_3d","scorpion_3d","butterfly_3d","honeybee_3d","cricket_3d"]
    let birds = ["parrot_3d","chipmunk_3d","sloth_3d","nest_with_eggs_3d","bat_3d","owl_3d","dove_3d","bird_3d"]
    let animals = ["snake_3d","tiger_3d","gorilla_3d","orangutan_3d","elephant_3d","rhinoceros_3d","badger_3d","skunk_3d","deer_3d"]
    
    let synthesizer = AVSpeechSynthesizer() // AVSpeechSynthesizerのインスタンスを作成
    // メッセージを読み上げる関数
    func speakMessage(message: String) {
        let utterance = AVSpeechUtterance(string: message)
        
        // ピッチを上げる (例: 1.5 で少し高くする)
        utterance.pitchMultiplier = 1.5
        
        // 読み上げ速度を遅くする (例: AVSpeechUtteranceDefaultSpeechRate * 0.8 で少し遅くする)
        utterance.rate = AVSpeechUtteranceDefaultSpeechRate * 0.8

        
        if let voice = AVSpeechSynthesisVoice(identifier: "com.apple.ttsbundle.Samantha-compact") {
            utterance.voice = voice
        } else {
            utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        }
        synthesizer.speak(utterance)
    }
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                LinearGradient(gradient: gradient, startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()
                LinearGradient(gradient: gradient2, startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()
                LinearGradient(gradient: gradient3, startPoint: .topLeading, endPoint: .bottom)
                    .ignoresSafeArea()
                LinearGradient(gradient: gradient4, startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()
                
                if !showingFlowers || !showingBugs || !showingBirds || !showingAnimals {
                    withAnimation(.bouncy){
                        VStack {
                            Text(messages[messageIndex])
                                .font(.title)
                                .fontDesign(.serif)
                                .padding()
                                .background(Color.white.opacity(0.8))
                                .border(.black)
                                // 読み上げボタン
                                Button(action: {
                                    speakMessage(message: messages[messageIndex]) // ボタンが押されたらメッセージを読み上げる
                                    isStorySpoken.toggle()
                                    if synthesizer.isSpeaking {
                                        synthesizer.stopSpeaking(at: .immediate)
                                    }
                                }) {
                                    Image(systemName: isStorySpoken ? "speaker.slash.circle.fill" : "speaker.wave.2.circle.fill") // 読み上げ状態によってアイコンを変更
                                        .font(.system(size: 50))
                                        .symbolRenderingMode(.palette) // パレットモードを設定
                                        .foregroundStyle(isStorySpoken ? Color.red : Color.blue, .white.opacity(0.8))
                                        .accessibilityLabel(isStorySpoken ? "Stop reading story" : "Read story aloud") //
                                }
                                .padding(.bottom)
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                        .padding()
                    }
                }
            
                let baseSize = min(geometry.size.width, geometry.size.height) * 0.1
                
                ForEach(0..<treeStates.count, id: \.self) { row in
                    let rowSpacing: CGFloat = geometry.size.width * 0.0001
                    let rowOffset: CGFloat = [-geometry.size.height * 0.13, -geometry.size.height * 0.08, 0, geometry.size.height * 0.08, geometry.size.height * 0.2][row]
                    
                    TreeRow(
                        size: baseSize*[1.0,1.3,1.5,1.8,2.2][row],
                        offsetY: rowOffset,
                        spacing: rowSpacing,
                        trees: $treeStates[row],
                        sliderValue: $sliderValue, // Sliderの値をBindingで渡す
                        sliderAppears: sliderAppears, // sliderAppearsの状態を渡す
                        onTap: { index in cutTree(at: row, index: index) }
                    )
                }
                
                if let logCount = logCount {
                    ZStack { // ZStackで🪧と🪵カウンターを重ねる
                        Image("placard_3d")
                            .resizable()
                            .scaledToFit()
                            .frame(width: geometry.size.width * 0.2) // 🪧の幅を調整
                            .overlay {
                                // ログカウンター（🪧の中央やや上）
                                HStack {
                                    Image("wood_3d")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: geometry.size.width * 0.06)
                                    Text("×\(logCount)")
                                        .font(.system(size: max(35, baseSize * 0.7)))
                                        .foregroundColor(logCount == 12 ? .pink : .black.opacity(0.7))
                                }
                                .offset(y: -geometry.size.height * 0.035) // 🪧の中央から少し上に調整
                            }
                    }
                    .offset(x: -40)
                    .offset(y: 40)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomLeading)
                    .padding()
                    .accessibilityLabel("The number of trees you cut down is\(logCount)")
                }
                
                if showingComplimentations {
                    Color.white.opacity(0.8)
                        .ignoresSafeArea()
                    Text(complimentations[complimentationIndex])
                        .font(.system(size: 56, weight: .bold))
                        .fontDesign(.serif)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.green)
                        .cornerRadius(8)
                        .accessibilityLabel(complimentations[complimentationIndex])
                }
                
                if plantAppears && remainingPlants > 0 {
                    // 画面下中央に固定表示される🪴
                    Image("potted_plant_3d")
                        .resizable()
                        .scaledToFit()
                        .frame(width: geometry.size.width * 0.08)
                        .background{
                            RoundedRectangle(cornerRadius: 18)
                                .foregroundColor(.white)
                                .frame(width: 100, height: 100)
                                .shadow(color: .black.opacity(0.8), radius: 5, x:0, y: 7)
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                        .accessibilityLabel("Double-tap here to move 🌱 to 🕳️.")
                        .padding(.bottom, 20) 
                        .gesture(
                            DragGesture(minimumDistance: 0)
                                .onChanged { gesture in
                                    isDragging = true
                                    plantPosition = gesture.location // 指を動かした瞬間に追従させる
                                }
                                .onEnded { gesture in
                                    let droppedPosition = gesture.location
                                    checkPlanting(at: droppedPosition)
                                    isDragging = false
                                    plantPosition = nil
                                }
                        )
                        .overlay{
                            Image(systemName: "arrow.up")
                                .font(.system(size: max(80, baseSize * 0.7)))
                                .foregroundStyle(Color.white.opacity(0.9))
                                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                                .padding(.bottom, 130) 
                        }
                    // ドラッグ中の🪴
                    if isDragging {
                        Image("potted_plant_3d")
                            .resizable()
                            .scaledToFit()
                            .frame(width: geometry.size.width * 0.15)
                            .position(plantPosition ?? CGPoint(x: geometry.size.width / 2, y: geometry.size.height - 60))
                            .gesture(
                                DragGesture(minimumDistance: 0)
                                    .onChanged { gesture in
                                        plantPosition = gesture.location
                                    }
                                    .onEnded { gesture in
                                        let droppedPosition = gesture.location
                                        checkPlanting(at: droppedPosition)
                                        isDragging = false
                                        plantPosition = nil
                                    }
                            )
                    }
                }
                
                if mulchingAppears && remainingMulching > 0 {
                    // 画面下中央に固定表示される🟤
                    Image("brown_circle_3d")
                        .resizable()
                        .scaledToFit()
                        .frame(width: geometry.size.width * 0.08)
                        .background{
                            RoundedRectangle(cornerRadius: 18)
                                .foregroundColor(.white)
                                .frame(width: 100, height: 100)
                                .shadow(color: .black.opacity(0.8), radius: 5, x:0, y: 7)
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                        .accessibilityLabel("Double-tap here to move 🟤 to the 🌱.")
                        .padding(.bottom, 20) 
                        .gesture(
                            DragGesture(minimumDistance: 0)
                                .onChanged { gesture in
                                    isDragging = true
                                    mulchingPosition = gesture.location // 指を動かした瞬間に追従させる
                                }
                                .onEnded { gesture in
                                    let droppedPosition = gesture.location
                                    checkMulching(at: droppedPosition)
                                    isDragging = false
                                }
                        )
                        .overlay{
                            Image(systemName: "arrow.up")
                                .font(.system(size: max(80, baseSize * 0.7)))
                                .foregroundStyle(Color.white.opacity(0.9))
                                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                                .padding(.bottom, 130) 
                        }
                    // ドラッグ中の🟤
                    if isDragging {
                        Image("brown_circle_3d")
                            .resizable()
                            .scaledToFit()
                            .frame(width: geometry.size.width * 0.15)
                            //.opacity(0.7)
                            .font(.system(size: max(140, baseSize * 0.7)))
                            .position(mulchingPosition ?? CGPoint(x: geometry.size.width / 2, y: geometry.size.height - 60))
                            .gesture(
                                DragGesture(minimumDistance: 0)
                                    .onChanged { gesture in
                                        mulchingPosition = gesture.location
                                    }
                                    .onEnded { gesture in
                                        let droppedPosition = gesture.location
                                        checkMulching(at: droppedPosition)
                                        isDragging = false
                                        mulchingPosition = nil
                                    }
                            )
                    }
                }
                
                if sliderAppears {
                    HStack(spacing: 18) { // スペーシングを追加
                        // Slider部分
                        Slider(value: $sliderValue, in: 0...1)
                            .onChange(of: sliderValue) { oldValue, newValue in
                                hasSliderReachedEnd = newValue >= 0.99
                                    if hasSliderReachedEnd {
                                        sliderAppears = false
                                        showComplimentation()
                                        SoundPlayer.shared.playWonderfulSound()
                                        for row in 0..<treeStates.count {
                                            for col in 0..<treeStates[row].count {
                                                var treeState = treeStates[row][col] // 中間変数 treeState を導入
                                                if treeState.isSliderControlled {
                                                    treeState.isFullyGrown = true
                                                    treeStates[row][col] = treeState // 構造体なので、変更を反映するために再代入が必要
                                                }
                                            }
                                        }
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                                            animalButtonsAppears = true
                                    }
                                }
                            }
                            .accentColor(.green)
                            .padding()
                            .frame(height: 60)
                            .background(Color.white.opacity(0.8))
                            .cornerRadius(60)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                    .padding(.bottom) 
                    .padding(.horizontal) 
                }
                
                    if animalButtonsAppears {
                        HStack {
                            Button{
                                showFlowers()
                                SoundPlayer.shared.playAnimalsSound()
                                withAnimation(.linear(duration: 3.0)){
                                    gradient2 = Gradient(stops: [
                                        .init(color: .clear, location: 0.0),
                                        .init(color: .black.opacity(0.95), location: 0.5),
                                        .init(color: .black.opacity(0.85), location: 0.75),
                                        .init(color: .black.opacity(0.75), location: 1.0)
                                    ])
                                    gradient4 = Gradient(stops: [
                                        .init(color: .blue, location: 0.0),
                                        .init(color: .green.opacity(0.3), location: 0.4),
                                        .init(color: .green.opacity(0.6), location: 1.0)
                                    ])
                                }
                            } label: {
                                Image(systemName: showingFlowers ?  "leaf.circle.fill" : "leaf.circle")
                                    .font(.system(size: 50))
                                    .foregroundStyle(showingFlowers ? Color.green : Color.blue)
                                    .padding()
                            }.accessibilityLabel("Tap here and flowers will appear.")

                            Button{
                                showBugs()
                                SoundPlayer.shared.playAnimalsSound()
                            } label: {
                                Image(systemName: showingBugs ? "ladybug.circle.fill" : "ladybug.circle")
                                    .font(.system(size: 50))
                                    .foregroundStyle(showingBugs ? Color.green : Color.blue)
                                    .padding()
                            }.accessibilityLabel("Tap here and bugs will appear.")
                            
                            Button{
                                showBirds()
                                SoundPlayer.shared.playAnimalsSound()
                                 SoundPlayer.shared.playRedWoodSound()
                            } label: {
                                Image(systemName: showingBirds ? "bird.circle.fill" : "bird.circle")
                                    .font(.system(size: 50))
                                    .foregroundStyle(showingBirds ? Color.green : Color.blue)
                                    .padding()
                            }.accessibilityLabel("Tap here and birds will appear.")
                            
                            Button{
                                 SoundPlayer.shared.playAnimalsSound()
                                showAnimals()
                            } label: {
                                Image(systemName: showingAnimals ? "pawprint.circle.fill" : "pawprint.circle")
                                    .font(.system(size: 50))
                                    .foregroundStyle(showingAnimals ? Color.green : Color.blue)
                                    .padding()
                            }.accessibilityLabel("Tap here and animals will appear.")
                        }
                        .background(.white.opacity(0.8))
                        .cornerRadius(60)
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                        .opacity( showingFlowers && showingBugs && showingBirds && showingAnimals ? 0.0 : 1.0)
                        .padding(.bottom, 10) 
                    }
                
                if isDrawingCanvasVisible && showingFlowers && showingBugs && showingBirds && showingAnimals {
                    DrawingCanvasView()
                        .frame(width: .infinity, height: .infinity)
                        .background(Color.clear)
                    Button(action: {
                        showingEndingView.toggle()
                        SoundPlayer.shared.playEndingSound()
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                            SoundPlayer.shared.playPipSound()
                            isDrawingCanvasVisible = false
                        }
                        if isListening { // isListeningがtrue（再生中）の場合のみ停止処理を行う
                            SoundPlayer.shared.playRedWoodSound() // もう一度呼び出すことで停止
                        }
                    }) {
                        Text("Done")
                        .fontWeight(.bold)
                        .foregroundStyle(Color.blue)
                        .padding()
                        .background(.white)
                        .font(.system(size: 20))
                        .cornerRadius(60)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
                    .padding() 
                    .accessibilityLabel("Tap here to move to the next screen")
                    .navigationDestination(isPresented: $showingEndingView) { 
                        EndingView()
                    }
                    
                    Button(action: {
                         SoundPlayer.shared.playRedWoodSound()
                         isListening.toggle()
                    }) {
                        Image(systemName: isListening ? "bell.slash.circle.fill" : "bell.circle.fill")
                            .font(.system(size: 50))
                            .symbolRenderingMode(.palette) // パレットモードを設定
                            .foregroundStyle(isListening ? Color.red : Color.blue, .white)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                    .padding() 
                    .accessibilityLabel(isListening ? "Tap here to stop the forest sound." : "Tap here to play the forest sound.")
                }
            }
            .fullScreenCover(isPresented: $showingHowWoodUsed) { // ここに sheet モディファイアを追加
                HowWoodIsUsedView(showingHowWoodUsed: $showingHowWoodUsed, plantAppears: $plantAppears)// sheetで表示するViewを指定
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .navigationBarBackButtonHidden(true)
            .preferredColorScheme(.light)
        }
    }
    
    struct DrawingCanvasView: UIViewRepresentable {
        let canvasView = PKCanvasView()
        let toolPicker = PKToolPicker()
        
        func makeUIView(context: Context) -> PKCanvasView {
            canvasView.backgroundColor = UIColor.clear
            canvasView.isOpaque = false
            canvasView.drawingPolicy = .anyInput
            
            DispatchQueue.main.async {
                toolPicker.setVisible(true, forFirstResponder: canvasView)
                toolPicker.addObserver(canvasView)
                canvasView.becomeFirstResponder()
            }
            return canvasView
        }
        
        func updateUIView(_ uiView: PKCanvasView, context: Context) {}
        
        static func dismantleUIView(_ uiView: PKCanvasView, coordinator: ()) {
            DispatchQueue.main.async {
                let toolPicker = PKToolPicker()
                toolPicker.setVisible(false, forFirstResponder: uiView)
                toolPicker.removeObserver(uiView)
            }
        }
    }
        
    struct HowWoodIsUsedView: View {
        @Binding var showingHowWoodUsed: Bool
        @Binding var plantAppears: Bool // plantAppears をバインディングとして受け取る
        @State private var isMessageSpoken = false
        
        let synthesizer2 = AVSpeechSynthesizer() // AVSpeechSynthesizerのインスタンスを作成
        
        func speakMessage2(message: String) {
            let utterance = AVSpeechUtterance(string: message)
            
            // ピッチを上げる (例: 1.5 で少し高くする)
            utterance.pitchMultiplier = 1.5
            
            // 読み上げ速度を遅くする (例: AVSpeechUtteranceDefaultSpeechRate * 0.8 で少し遅くする)
            utterance.rate = AVSpeechUtteranceDefaultSpeechRate * 0.8
            
            
            if let voice = AVSpeechSynthesisVoice(identifier: "com.apple.ttsbundle.Samantha-compact") {
                utterance.voice = voice
            } else {
                utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
            }
            synthesizer2.speak(utterance)
        }
        
        var body: some View {
            ScrollView{
                VStack{
                    Text("You’re worried that the wood you have cut will be thrown away, right? Don’t worry! I’ve sprinkled some glittering powder on the tree. Look what happens when you cut down a tree. We can turn it into a useful product.\"")
                        .font(.title)
                        .fontDesign(.serif)
                        .padding(20)
                        .background(.white.opacity(0.8))
                        .border(Color.black)
                        .padding()
                    
                    Button(action: {
                        speakMessage2(message: "You’re worried that the wood you have cut will be thrown away, right? Don’t worry! I’ve sprinkled some glittering powder on the tree. Look what happens when you cut down a tree. We can turn it into a useful product.\"")
                        isMessageSpoken.toggle()
                        if synthesizer2.isSpeaking {
                            synthesizer2.stopSpeaking(at: .immediate)
                        }
                    }) {
                        Image(systemName: isMessageSpoken ? "speaker.slash.circle.fill" : "speaker.wave.2.circle.fill") // 読み上げ状態によってアイコンを変更
                            .font(.system(size: 50))
                            .symbolRenderingMode(.palette) // パレットモードを設定
                            .foregroundStyle(isMessageSpoken ? Color.red : Color.blue, .white.opacity(0.8))
                            .padding(.bottom,200)
                    } .accessibilityLabel(isMessageSpoken ? "Stop reading story" : "Read story aloud") //
                    Spacer()
                    VStack{
                        Image("wood_3d")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 240, height: 240)
                            .background(
                                Image("Sparkle")
                                    .resizable()
                                    .scaledToFit()
                                    .clipShape(Circle())
                                    .frame(width: 1100, height: 1100)
                            .overlay{
                                    Image("page_with_curl_3d")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 200, height: 200)
                                        .offset(y: 280)
                                        .padding()
                                        .shadow(radius: 5)
                                Image("package_3d")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 200, height: 200)
                                    .offset(x: -280)
                                        .padding()
                                        .shadow(radius: 5)
                                Image("roll_of_paper_3d")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 200, height: 200)
                                    .offset(x: 280)
                                        .padding()
                                        .shadow(radius: 5)
                                Image("ladder_3d")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 200, height: 200)
                                       .offset(y: -280)
                                        .padding()
                                        .shadow(radius: 5)
                            }
                                )
                        .padding()
                    }.accessibilityLabel("The trees you cut have been transformed into a variety of products.")
                    
                    .padding(.vertical, 100)
                    
                    Spacer()
                    
                    Button(action: {
                        withAnimation(.easeOut){
                            showingHowWoodUsed = false
                        }
                        plantAppears = true
                        if isMessageSpoken{
                            isMessageSpoken.toggle()
                        }
                    }) {
                        Text("OK")
                            .font(.largeTitle)
                            .padding(.vertical)
                            .padding(.horizontal,80)
                            .foregroundStyle(Color.white)
                            .background(.blue)
                            .cornerRadius(16)
                    }.accessibilityLabel("Tap here to proceed to the next story.")
                    .padding(.top,200)
                    .padding(.bottom, 60)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .background(Color.white)
        }
    }

    private func cutTree(at row: Int, index: Int) {
        guard !isCuttingDisabled, !treeStates[row][index].isCut && (logCount ?? 0) < 12 else { return }
        
        treeStates[row][index].isBeingCut = true // 伐採アニメーション開始
        SoundPlayer.shared.playTreeSound()
        logCount = (logCount ?? 0) + 1
        treeStates[row][index].isHole = ((logCount ?? 0) % 2 == 0)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
            if (logCount ?? 0) >= 1 {
                gradient2 = Gradient(stops: [
                    .init(color: .clear, location: 0.0),
                    .init(color: .black.opacity(0.95), location: 0.5),
                    .init(color: .black.opacity(0.85), location: 0.75),
                    .init(color: .black.opacity(0.75), location: 1.0)
                ])
            }
            
            if (logCount ?? 0) >= 2 {
                gradient2 = Gradient(stops: [
                    .init(color: .clear, location: 0.0),
                    .init(color: .black.opacity(0.9), location: 0.5),
                    .init(color: .black.opacity(0.8), location: 0.75),
                    .init(color: .black.opacity(0.7), location: 1.0)
                ])
            }
            
            if (logCount ?? 0) >= 3 {
                gradient2 = Gradient(stops: [
                    .init(color: .clear, location: 0.0),
                    .init(color: .black.opacity(0.85), location: 0.5),
                    .init(color: .black.opacity(0.75), location: 0.75),
                    .init(color: .black.opacity(0.65), location: 1.0)
                ])
            }
            
            if (logCount ?? 0) >= 4 {
                gradient2 = Gradient(stops: [
                    .init(color: .clear, location: 0.0),
                    .init(color: .black.opacity(0.8), location: 0.5),
                    .init(color: .black.opacity(0.7), location: 0.75),
                    .init(color: .black.opacity(0.6), location: 1.0)
                ])
            }
            
            if (logCount ?? 0) >= 5 {
                gradient2 = Gradient(stops: [
                    .init(color: .clear, location: 0.0),
                    .init(color: .black.opacity(0.75), location: 0.5),
                    .init(color: .black.opacity(0.65), location: 0.75),
                    .init(color: .black.opacity(0.55), location: 1.0)
                ])
            }
            
            if (logCount ?? 0) >= 6 {
                gradient2 = Gradient(stops: [
                    .init(color: .clear, location: 0.0),
                    .init(color: .black.opacity(0.7), location: 0.5),
                    .init(color: .black.opacity(0.6), location: 0.75),
                    .init(color: .black.opacity(0.5), location: 1.0)
                ])
            }
            
            if (logCount ?? 0) >= 7 {
                gradient2 = Gradient(stops: [
                    .init(color: .clear, location: 0.0),
                    .init(color: .black.opacity(0.65), location: 0.5),
                    .init(color: .black.opacity(0.55), location: 0.75),
                    .init(color: .black.opacity(0.45), location: 1.0)
                ])
            }
            
            if (logCount ?? 0) >= 8 {
                gradient2 = Gradient(stops: [
                    .init(color: .clear, location: 0.0),
                    .init(color: .black.opacity(0.6), location: 0.5),
                    .init(color: .black.opacity(0.5), location: 0.75),
                    .init(color: .black.opacity(0.4), location: 1.0)
                ])
            }
            
            if (logCount ?? 0) >= 9 {
                gradient2 = Gradient(stops: [
                    .init(color: .clear, location: 0.0),
                    .init(color: .black.opacity(0.55), location: 0.5),
                    .init(color: .black.opacity(0.45), location: 0.75),
                    .init(color: .black.opacity(0.35), location: 1.0)
                ])
            }
            
            if (logCount ?? 0) >= 10 {
                gradient2 = Gradient(stops: [
                    .init(color: .clear, location: 0.0),
                    .init(color: .black.opacity(0.5), location: 0.5),
                    .init(color: .black.opacity(0.4), location: 0.75),
                    .init(color: .black.opacity(0.3), location: 1.0)
                ])
            }
            
            if (logCount ?? 0) >= 11 {
                gradient2 = Gradient(stops: [
                    .init(color: .clear, location: 0.0),
                    .init(color: .black.opacity(0.45), location: 0.5),
                    .init(color: .black.opacity(0.35), location: 0.75),
                    .init(color: .black.opacity(0.25), location: 1.0)
                ])
            }
            
            if (logCount ?? 0) >= 12 {
                gradient2 = Gradient(stops: [
                    .init(color: .clear, location: 0.0),
                    .init(color: .black.opacity(0.4), location: 0.5),
                    .init(color: .black.opacity(0.3), location: 0.75),
                    .init(color: .black.opacity(0.2), location: 1.0)
                ])
            }
        }
        
        if (logCount ?? 0) == 12 {
            SoundPlayer.shared.playNiceSound()
            showComplimentation()
            isCuttingDisabled = true
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                showingHowWoodUsed = true
                logCount = nil
                
                for row in 0..<treeStates.count {
                    for col in 0..<treeStates[row].count {
                        if treeStates[row][col].isHole {
                            treeStates[row][col].showingHole = true // 🕳️表示
                        }
                    }
                }
            }
        }
        // 🪓アニメーション後に🕳️または⛳️に変化
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
            treeStates[row][index].isCut = true
            treeStates[row][index].isBeingCut = false
        }
    }
    
    private func showComplimentation() {
        if synthesizer.isSpeaking {
            synthesizer.stopSpeaking(at: .immediate)
        }
        if isStorySpoken{
            isStorySpoken.toggle()
        }
        showingComplimentations = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            showingComplimentations = false
            if complimentationIndex < complimentations.count - 1 { // 👈🏻 範囲チェックを追加
                complimentationIndex += 1
            } else {
                complimentationIndex = 0 // または、範囲内に収まるようにリセットするなどの処理
            }
            if messageIndex < messages.count - 1 { // 👈🏻 範囲チェックを追加
                messageIndex += 1
            } else {
                messageIndex = 4 // または、範囲内に収まるようにリセットするなどの処理
            }
        }
    }
    
    private func calculateHolePosition(row: Int, col: Int) -> CGPoint {
        let baseSize: CGFloat = 50 // 🕳️の基準サイズ（調整可）
        let rowOffset: CGFloat = [-130, -80, 0, 80, 200][row] // 各行のオフセット
        
        return CGPoint(
            x: CGFloat(col) * baseSize + baseSize,
            y: CGFloat(row) * 60 + rowOffset
        )
    }
    
    private func checkPlanting(at position: CGPoint) {
        var closestRow: Int? = nil
        var closestCol: Int? = nil
        var minDistance: CGFloat = .greatestFiniteMagnitude
        
        for row in 0..<treeStates.count {
            for col in 0..<treeStates[row].count {
                if treeStates[row][col].isHole && treeStates[row][col].showingHole {
                    //🕳️の位置を推定
                    let holePosition = calculateHolePosition(row: row, col: col)
                    let distance = hypot(holePosition.x - position.x, holePosition.y - position.y)
                    
                    if distance < minDistance {
                        minDistance = distance
                        closestRow = row
                        closestCol = col
                    }
                }
            }
        }
        
        if let row = closestRow, let col = closestCol {
            SoundPlayer.shared.playPlantSound() //🌱を植えた音を再生
            treeStates[row][col].isHole = false
            treeStates[row][col].isSeedling = true
            treeStates[row][col].showingSeedling = true
            treeStates[row][col].wasSeedling = true // 🌱だったことを記録
            
            
            remainingPlants -= 1
            plantPosition = nil
            
            if remainingPlants == 0 {
                SoundPlayer.shared.playGreatSound()
                showComplimentation()
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    mulchingAppears = true
                }
            }
        }
    }
    
    private func calculatePlantPosition(row: Int, col: Int) -> CGPoint {
        let baseSize: CGFloat = 50
        let rowOffset: CGFloat = [-130, -80, 0, 80, 200][row]
        return CGPoint(
            x: CGFloat(col) * baseSize + baseSize,
            y: CGFloat(row) * 60 + rowOffset
        )
    }
    
    private func checkMulching (at position: CGPoint) {
        var closestRow: Int? = nil
        var closestCol: Int? = nil
        var minDistance: CGFloat = .greatestFiniteMagnitude
        
        for row in 0..<treeStates.count {
            for col in 0..<treeStates[row].count {
                if treeStates[row][col].isSeedling && treeStates[row][col].showingSeedling && treeStates[row][col].mulchingStage < 3 {
                    //🌱の位置を推定
                    let plantPosition = calculatePlantPosition(row: row, col: col)
                    let distance = hypot(plantPosition.x - position.x, plantPosition.y - position.y)
                    
                    if distance < minDistance {
                        minDistance = distance
                        closestRow = row
                        closestCol = col
                    }
                }
            }
        }
        
        if let row = closestRow, let col = closestCol {
            treeStates[row][col].mulchingStage += 1 // 🟤をoverlay
            treeStates[row][col].showingMulching = true
            
            SoundPlayer.shared.playMulchingSound() //🟤を植えた音を再生
            
            remainingMulching -= 1
            mulchingPosition = nil
            
            let mulchingOffsetY: CGFloat = 30 // この値を調整して下げる量を変更
            
            // 🟤の位置を調整
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { // 少し遅延させることで、アニメーションがスムーズになる場合がある
                withAnimation { // アニメーションを追加
                    treeStates[row][col].mulchingOffset = mulchingOffsetY // offsetを追加
                }
            }
            
            if remainingMulching == 0 {
                SoundPlayer.shared.playExcellentSound()
                showComplimentation()
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    sliderAppears = true
                    // Excellent!表示終了後に🌱をopacity0にする
                    var sliderControlledCount = 0 // Slider制御される🌱の数をカウント
                    for row in 0..<treeStates.count {
                        for col in 0..<treeStates[row].count {
                            if treeStates[row][col].wasSeedling && sliderControlledCount < 9 { // 元🌱だった場所から9個まで
                                treeStates[row][col].showingSeedling = false // 元の🌱を非表示に
                                treeStates[row][col].isSliderControlled = true // Slider制御対象にする
                                treeStates[row][col].mulchingStage = 0
                                sliderControlledCount += 1
                            } else if treeStates[row][col].wasSeedling {
                                treeStates[row][col].mulchingStage = 0
                            }
                        }
                    }
                }
            }
        }
    }
    
    private func showFlowers() {
        showingFlowers = true // 動物表示状態を true に設定
        
        for row in 0..<treeStates.count {
            for col in 0..<treeStates[row].count {
                if treeStates[row][col].isCut && !treeStates[row][col].hasFlower { // 🌳かつ花未表示の場合
                    if let randomFlower = flowers.randomElement() {
                        treeStates[row][col].flowerEmoji = randomFlower // ランダムな動物絵文字を設定
                        treeStates[row][col].hasFlower = true // 動物表示済みに設定
                    }
                }
            }
        }
    }
    
    private func showBugs() {
        showingBugs = true // 動物表示状態を true に設定
        
        for row in 0..<treeStates.count {
            for col in 0..<treeStates[row].count {
                if !treeStates[row][col].isCut && !treeStates[row][col].hasBug { //🌲かつ虫未表示の場合
                    if let randomBug = bugs.randomElement() {
                        treeStates[row][col].bugEmoji = randomBug // ランダムな動物絵文字を設定
                        treeStates[row][col].hasBug = true // 動物表示済みに設定
                    }
                }
            }
        }
    }
    
    private func showBirds() {
        showingBirds = true // 動物表示状態を true に設定
        
        for row in 0..<treeStates.count {
            for col in 0..<treeStates[row].count {
                if treeStates[row][col].isCut && treeStates[row][col].isSeedling && !treeStates[row][col].hasBird { // 🌳かつ鳥未表示の場合
                    if let randomBird = birds.randomElement() {
                        treeStates[row][col].birdEmoji = randomBird // ランダムな動物絵文字を設定
                        treeStates[row][col].hasBird = true // 動物表示済みに設定
                    }
                }
            }
        }
    }
    
    private func showAnimals() {
        showingAnimals = true // 動物表示状態を true に設定
        
        for row in 0..<treeStates.count {
            for col in 0..<treeStates[row].count {
                if treeStates[row][col].isCut && !treeStates[row][col].isSeedling && !treeStates[row][col].isHole && !treeStates[row][col].hasAnimal { // ⛳️ かつ動物未表示の場合
                    if let randomAnimal = animals.randomElement() {
                        treeStates[row][col].animalEmoji = randomAnimal // ランダムな動物絵文字を設定
                        treeStates[row][col].hasAnimal = true // 動物表示済みに設定
                    }
                }
            }
        }
    }
    
    struct TreeRow: View {
        let size: CGFloat
        let offsetY: CGFloat
        let spacing: CGFloat
        @Binding var trees: [TreeState]
        @Binding var sliderValue: Double // Sliderの値をBindingで受け取る
        var sliderAppears: Bool // sliderAppearsの状態を受け取る
        var onTap: (Int) -> Void
        
        // Sliderの値に応じて変化する🌱のView
        @ViewBuilder
        func MulchingPebbleView(size: CGFloat, mulchingOffset: CGFloat, scale: CGFloat, xOffset: CGFloat = 0, yOffset: CGFloat = 0) -> some View {
            Image("brown_circle_3d")
                .resizable()
                .scaledToFit()
                .offset(x: xOffset + mulchingOffset, y: yOffset + mulchingOffset)
                .scaleEffect(scale)
        }
        
        @ViewBuilder
        func seedlingStageView(for index: Int) -> some View {
            let stage = min(Int(sliderValue * 46),46) // 0, 1, 2, 3,,, 46 の47段階
            let opacity = (sliderAppears && trees[index].isSliderControlled) || trees[index].isFullyGrown ? 1.0 : 0.0
            let co2CloudImage = Image(systemName: "carbon.dioxide.cloud.fill")
                                   .foregroundColor(.black.opacity(0.8))
            
            switch stage {
            case 0:
                let seedlingScale: CGFloat = 0.5 // スケールを中間変数に
                let seedlingOffsetY = size * 0.4   // Yオフセットを中間変数に
                let pebbleSize05 = size * 0.5      // MulchingPebbleView のサイズを中間変数に
                let pebbleScale03: CGFloat = 0.3   // MulchingPebbleView のスケールを中間変数に (型注釈を追加)
                let pebbleXOffset025 = size * 0.25 // MulchingPebbleView の Xオフセットを中間変数に
                let pebbleYOffset17 = size * 1.7  // MulchingPebbleView の Yオフセットを中間変数に
                let pebbleSize06 = size * 0.6      // overlay の MulchingPebbleView のサイズを中間変数に
                let pebbleXOffsetNegative005 = size * -0.05 // overlay の MulchingPebbleView の Xオフセットを中間変数に
                let pebbleYOffset20 = size * 2.0  // overlay の MulchingPebbleView の Yオフセットを中間変数に
                
                
                Image("seedling_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(seedlingScale)         // 中間変数を使用
                    .offset(y: seedlingOffsetY)        // 中間変数を使用
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: pebbleSize05, mulchingOffset: trees[index].mulchingOffset, scale: pebbleScale03, xOffset: pebbleXOffset025, yOffset: pebbleYOffset17)) // 中間変数を使用
                    .background(MulchingPebbleView(size: pebbleSize05, mulchingOffset: trees[index].mulchingOffset, scale: pebbleScale03, yOffset: pebbleYOffset17)) // 中間変数を使用 (繰り返し部分も修正)
                    .overlay(MulchingPebbleView(size: pebbleSize06, mulchingOffset: trees[index].mulchingOffset, scale: pebbleScale03, xOffset: pebbleXOffsetNegative005, yOffset: pebbleYOffset20)) // 中間変数を使用
                    .overlay(co2CloudImage.font(.system(size: size * 0.7)).offset(x: size * 0.5, y: size * -0.8)) // 中間変数を使用
            case 1:
                Image("seedling_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.5)
                    .offset(y: size * 0.4)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7))
                    .background(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7))
                    .overlay(MulchingPebbleView(size: size * 0.55, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.65)).offset(x: size * 0.45, y: size * -0.7))
            case 2:
                Image("seedling_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.5)
                    .offset(y: size * 0.4)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7))
                    .background(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7))
                    .overlay(MulchingPebbleView(size: size * 0.55, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.6)).offset(x: size * 0.4, y: size * -0.6)) // 中間変数を使用
                
            case 3:
                Image("seedling_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.5)
                    .offset(y: size * 0.4)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7))
                    .background(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7))
                    .overlay(MulchingPebbleView(size: size * 0.55, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.55)).offset(x: size * 0.35, y: size * -0.5))
                
            case 4:
                Image("seedling_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.5)
                    .offset(y: size * 0.4)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7))
                    .background(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7))
                    .overlay(MulchingPebbleView(size: size * 0.55, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.5)).offset(x: size * 0.3, y: size * -0.4)) 
                
            case 5:
                Image("seedling_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.5)
                    .offset(y: size * 0.4)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7))
                    .background(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7))
                    .overlay(MulchingPebbleView(size: size * 0.55, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.45)).offset(x: size * 0.25, y: size * -0.3))
            case 6:
                Image("seedling_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.5)
                    .offset(y: size * 0.4)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7))
                    .background(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7))
                    .overlay(MulchingPebbleView(size: size * 0.55, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.4)).offset(x: size * 0.2, y: size * -0.2))
                
            case 7:
                Image("seedling_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.5)
                    .offset(y: size * 0.4)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7))
                    .background(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7))
                    .overlay(MulchingPebbleView(size: size * 0.55, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.35)).offset(x: size * 0.15, y: size * -0.1))
                
            case 8:
                Image("seedling_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.5)
                    .offset(y: size * 0.4)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7))
                    .background(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7))
                    .overlay(MulchingPebbleView(size: size * 0.55, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.3)).offset(x: size * 0.1, y: size * 0.0))
            case 9:
                Image("seedling_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.5)
                    .offset(y: size * 0.4)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7))
                    .background(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7))
                    .overlay(MulchingPebbleView(size: size * 0.55, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.25)).offset(x: size * 0.05, y: size * 0.1))
            case 10:
                Image("seedling_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.5)
                    .offset(y: size * 0.4)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7))
                    .background(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7))
                    .overlay(MulchingPebbleView(size: size * 0.55, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.2)).offset(x: size * -0.05, y: size * 0.2))
            case 11:
                Image("seedling_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.5)
                    .offset(y: size * 0.4)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7))
                    .background(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7))
                    .overlay(MulchingPebbleView(size: size * 0.55, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.15)).offset(x: size * -0.15, y: size * 0.3))
                    
            case 12:
                Image("seedling_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.6)
                    .offset(y: size * 0.35)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.4, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7))
                    .background(MulchingPebbleView(size: size * 0.4, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7))
                    .overlay(MulchingPebbleView(size: size * 0.5, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                     .accessibilityValue("The seedlings you planted are growing while absorbing carbon dioxide") // アクセシビリティValue追加
            case 13:
                Image("seedling_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.55)
                    .offset(y: size * 0.35)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.35, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7))
                    .background(MulchingPebbleView(size: size * 0.35, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7))
                    .overlay(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                
            case 14:
                Image("seedling_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.65)
                    .offset(y: size * 0.35)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.35, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7))
                    .background(MulchingPebbleView(size: size * 0.35, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7))
                    .overlay(MulchingPebbleView(size: size * 0.45, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                
            case 15:
                Image("seedling_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.7)
                    .offset(y: size * 0.3)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.3, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7))
                    .background(MulchingPebbleView(size: size * 0.3, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7))
                    .overlay(MulchingPebbleView(size: size * 0.4, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                
            case 16: 
                Image("herb_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.7)
                    .offset(y: size * 0.3)
                    .rotationEffect(.degrees(-20.0))
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.35, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .accessibilityValue("The seedlings you planted have grown into medium-sized trees") // アクセシビリティValue追加

            case 17:  //CO2 2週目ここから
                Image("herb_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.7)
                    .offset(y: size * 0.3)
                    .rotationEffect(.degrees(-20.0))
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.35, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                .overlay(co2CloudImage.font(.system(size: size * 0.7)).offset(x: size * 0.5, y: size * -0.8)) // 中間変数を使用
            case 18:
                Image("herb_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.7)
                    .offset(y: size * 0.3)
                    .rotationEffect(.degrees(-20.0))
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.35, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                     .overlay(co2CloudImage.font(.system(size: size * 0.65)).offset(x: size * 0.45, y: size * -0.7)) // 中間変数を使用
            case 19:
                Image("herb_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.7)
                    .offset(y: size * 0.3)
                    .rotationEffect(.degrees(-20.0))
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.35, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                   .overlay(co2CloudImage.font(.system(size: size * 0.6)).offset(x: size * 0.4, y: size * -0.6)) // 中間変数を使用
            case 20:
                Image("herb_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.7)
                    .offset(y: size * 0.3)
                    .rotationEffect(.degrees(-20.0))
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.35, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                .overlay(co2CloudImage.font(.system(size: size * 0.55)).offset(x: size * 0.35, y: size * -0.5)) // 中間変数を使用
            case 21:
                Image("herb_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.7)
                    .offset(y: size * 0.3)
                    .rotationEffect(.degrees(-20.0))
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.35, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.5)).offset(x: size * 0.3, y: size * -0.4)) // 中間変数を使用
                
            case 22:
                Image("herb_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.7)
                    .offset(y: size * 0.3)
                    .rotationEffect(.degrees(-20.0))
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.35, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.45)).offset(x: size * 0.25, y: size * -0.3)) 
            case 23:
                Image("herb_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.7)
                    .offset(y: size * 0.3)
                    .rotationEffect(.degrees(-20.0))
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.35, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.4)).offset(x: size * 0.2, y: size * -0.2))
            case 24:
                Image("herb_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.7)
                    .offset(y: size * 0.3)
                    .rotationEffect(.degrees(-20.0))
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.35, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.35)).offset(x: size * 0.15, y: size * -0.1))
            case 25:
                Image("herb_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.7)
                    .offset(y: size * 0.3)
                    .rotationEffect(.degrees(-20.0))
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.35, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.3)).offset(x: size * 0.1, y: size * 0.0)) // 中間変数を使用
                
            case 26:
                Image("herb_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.7)
                    .offset(y: size * 0.3)
                    .rotationEffect(.degrees(-20.0))
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.35, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.25)).offset(x: size * 0.05, y: size * 0.1))
            case 27:
                Image("herb_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.7)
                    .offset(y: size * 0.3)
                    .rotationEffect(.degrees(-20.0))
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.35, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.2)).offset(x: size * -0.05, y: size * 0.2))
            case 28:
                Image("herb_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.7)
                    .offset(y: size * 0.3)
                    .rotationEffect(.degrees(-20.0))
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.35, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                 .overlay(co2CloudImage.font(.system(size: size * 0.15)).offset(x: size * -0.15, y: size * 0.3)) // 中間変数を使用

               
            case 29:
                Image("herb_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.75)
                    .offset(y: size * 0.25)
                    .rotationEffect(.degrees(-20.0))
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.2, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.2, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.3, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                
            case 30:
                Image("herb_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.8)
                    .offset(y: size * 0.2)
                    .rotationEffect(.degrees(-20.0))
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.15, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.15, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.25, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                
            case 31:
                Image("deciduous_tree_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.8)
                    .offset(y: size * 0.2)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.2, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))  
                     .accessibilityValue("The seedlings you planted have grown into medium-sized trees") // アクセシビリティValue追加
            
            case 32: //CO2 3週目ここから
                Image("deciduous_tree_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.8)
                    .offset(y: size * 0.2)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.2, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.7)).offset(x: size * 0.5, y: size * -0.8)) // 中間変数を使用
                
            case 33:
                Image("deciduous_tree_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.8)
                    .offset(y: size * 0.2)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.2, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.65)).offset(x: size * 0.45, y: size * -0.7)) // 中間変数を使用
            case 34:
                Image("deciduous_tree_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.8)
                    .offset(y: size * 0.2)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.2, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                 .overlay(co2CloudImage.font(.system(size: size * 0.6)).offset(x: size * 0.4, y: size * -0.6)) // 中間変数を使用
                
            case 35:
                Image("deciduous_tree_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.8)
                    .offset(y: size * 0.2)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.2, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.55)).offset(x: size * 0.35, y: size * -0.5))
            case 36:
                Image("deciduous_tree_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.8)
                    .offset(y: size * 0.2)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.2, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.5)).offset(x: size * 0.3, y: size * -0.4))
                
            case 37:
                Image("deciduous_tree_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.8)
                    .offset(y: size * 0.2)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.2, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                      .overlay(co2CloudImage.font(.system(size: size * 0.45)).offset(x: size * 0.25, y: size * -0.3))
                
            case 38:
                Image("deciduous_tree_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.8)
                    .offset(y: size * 0.2)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.2, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.4)).offset(x: size * 0.2, y: size * -0.2))
                
            case 39:
                Image("deciduous_tree_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.8)
                    .offset(y: size * 0.2)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.2, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.3)).offset(x: size * 0.1, y: size * 0.0))
            case 40:
                Image("deciduous_tree_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.8)
                    .offset(y: size * 0.2)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.2, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                 .overlay(co2CloudImage.font(.system(size: size * 0.25)).offset(x: size * 0.05, y: size * 0.1)) 
            case 41:
                Image("deciduous_tree_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.8)
                    .offset(y: size * 0.2)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.2, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.2)).offset(x: size * -0.05, y: size * 0.2))
            case 42:
                Image("deciduous_tree_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.8)
                    .offset(y: size * 0.2)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.2, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
                    .overlay(co2CloudImage.font(.system(size: size * 0.15)).offset(x: size * -0.15, y: size * 0.3))
                
            case 43:
                Image("deciduous_tree_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.85)
                    .offset(y: size * 0.15)
                    .opacity(opacity)
                    .background(MulchingPebbleView(size: size * 0.05, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * 0.25, yOffset: size * 1.7).clipShape(Ellipse()))
                    .background(MulchingPebbleView(size: size * 0.05, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, yOffset: size * 1.7).clipShape(Ellipse()))
                    .overlay(MulchingPebbleView(size: size * 0.1, mulchingOffset: trees[index].mulchingOffset, scale: 0.3, xOffset: size * -0.05, yOffset: size * 2.0))
            case 44:
                Image("deciduous_tree_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.9)
                    .offset(y: size * 0.1)
                    .opacity(opacity)
                
            case 45:
                Image("deciduous_tree_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.95)
                    .offset(y: size * 0.05)
                    .opacity(opacity)
                
            case 46:
                Image("deciduous_tree_3d")
                    .resizable()
                    .scaledToFit()
                    .opacity(opacity)
                
            default:
                Image("deciduous_tree_3d")
                    .resizable()
                    .scaledToFit()
                    .opacity(opacity)
                    .accessibilityValue("The seedlings you planted have turned out to be magnificent. Congratulations!") // アクセシビリティValue追加
            }
        }
        
        @ViewBuilder
        func treeEmojiView(for index: Int) -> some View {
            if !trees[index].isCut {
                Image("evergreen_tree_3d")
                    .resizable()
                    .scaledToFit()
                    .onTapGesture { onTap(index) }
            }
        }
        
        @ViewBuilder
        func seedlingEmojiView(for index: Int) -> some View {
            if trees[index].isSeedling {
                Image("seedling_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.5)
                    .offset(y: size * 0.4)
                    .opacity(trees[index].showingSeedling ? 1.0 : 0.0)
                    .background{
                        if trees[index].mulchingStage >= 1 {
                            Image("brown_circle_3d")
                                .resizable()
                                .scaledToFit()
                                .offset(x: size * 0.25 + trees[index].mulchingOffset, y: size * 1.7 + trees[index].mulchingOffset)
                                .scaleEffect(0.3)
                        }
                    }
                    .background{
                        if trees[index].mulchingStage >= 2 {
                            Image("brown_circle_3d")
                                .resizable()
                                .scaledToFit()
                                .offset(y: size * 1.7 + trees[index].mulchingOffset)
                                .scaleEffect(0.3)
                        }
                    }
                    .overlay{
                        if trees[index].mulchingStage >= 3 {
                            Image("brown_circle_3d")
                                .resizable()
                                .scaledToFit()
                                .offset(x: size * -0.07 + trees[index].mulchingOffset, y: size * 2.0 + trees[index].mulchingOffset)
                                .scaleEffect(0.3)
                        }
                    }
                    .accessibilityElement(children: .ignore) // 苗とマルチング材をまとめて VoiceOver で読み上げないようにする
                    .accessibilityLabel("seedling") //  まとめて「苗」とラベル付け
                    .accessibilityValue("Mulching in progress") // 状態を Value で伝える
            }
        }
        
        @ViewBuilder
        func cutTreeEmojiView(for index: Int) -> some View {
            if trees[index].isCut && !trees[index].isSeedling { 
                // 🌲を透明化しつつ、その上に0.5倍サイズの🕳️または⛳️を重ねる
                Image("evergreen_tree_3d")
                    .resizable()
                    .scaledToFit()
                    .opacity(0)
                    .accessibilityLabel("A tree") // アクセシビリティラベル追加
                    .accessibilityHint("Tap to cut down a treeTree") // アクセシビリティヒント追加
                
                Image(trees[index].isHole ? "hole_3d" : "flag_in_hole_3d")
                    .resizable()
                    .scaledToFit()
                    .scaleEffect(0.5)
                    .offset(y: size * 0.4)
                    .opacity(trees[index].showingHole ? 0.6 : 0.0)
                    .clipShape(Ellipse())
            }
        }
        
        @ViewBuilder
        func axeAnimationView(for index: Int) -> some View {
            if trees[index].isBeingCut {
                AxeView(size: size * 0.5) {
                    trees[index].isBeingCut = false
                }
                .accessibilityHidden(true) 
            }
        }
        
        @ViewBuilder
        func sliderControlledSeedlingView(for index: Int) -> some View {
            if trees[index].isSliderControlled {
                seedlingStageView(for: index)
            }
        }
        
        @ViewBuilder
        func flowerEmojiView(for index: Int) -> some View {
            if let flower = trees[index].flowerEmoji { 
                Image(flower)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100)
                    .offset(x: size * -0.5) // 位置調整
                    .offset(y: size * 0.5) // 位置調整
                    .accessibilityLabel("Many flowers and mushrooms grew in the forest.The forest is gradually turning greener and greener.")
            }
        }
        
        @ViewBuilder
        func bugEmojiView(for index: Int) -> some View {
            if let bug = trees[index].bugEmoji { 
                Image(bug)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100)
                    .offset(y: size * 0.45) // 位置調整
                    .offset(x: size * 0.4) // 位置調整
                    .rotationEffect(.degrees(12.0))
                    .accessibilityLabel("Many insects gathered.")
            }
        }
        
        @ViewBuilder
        func birdEmojiView(for index: Int) -> some View {
            if let bird = trees[index].birdEmoji {
                Image(bird)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100)
                    .offset(x: size * -0.1) // 位置調整
                    .offset(y: size * -0.2) // 位置調整
                    .accessibilityLabel("Birds have gathered. You can hear their twittering.")
            }
        }
        
        @ViewBuilder
        func animalEmojiView(for index: Int) -> some View {
            if let animal = trees[index].animalEmoji { // animalEmoji が設定されている場合のみ表示
                Image(animal)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 160, height: 160)
                    .offset(y: size * 0.2) // 位置調整
                    .accessibilityLabel("The animals gathered. It's kind of lively.")
            }
        }
        
        var body: some View {
            HStack(spacing: spacing) {
                ForEach(trees.indices, id: \.self) { index in
                    ZStack {
                        treeEmojiView(for: index) // 🌲
                        seedlingEmojiView(for: index) // 🌱
                        cutTreeEmojiView(for: index) // 🕳️, ⛳️
                        axeAnimationView(for: index) // 🪓
                        sliderControlledSeedlingView(for: index) // スライダー制御
                        flowerEmojiView(for: index) 
                        bugEmojiView(for: index) 
                        birdEmojiView(for: index) 
                        animalEmojiView(for: index) // ...  動物表示
                    }
                    .offset(y: offsetY)
                }
            }
        }
    }
    
    struct AxeView: View {
        let size: CGFloat
        var onAnimationEnd: (() -> Void)? = nil
        @State private var rotation: Double = -20
        
        var body: some View {
            Image("axe_3d")
                .resizable()
                .scaledToFit()
                .rotationEffect(.degrees(rotation))
                .offset(x: size * 0.2, y: -size * 0.3)
                .onAppear {
                    withAnimation(Animation.easeInOut(duration: 0.2).repeatCount(2, autoreverses: true)) {
                        rotation = 20
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                        onAnimationEnd?() // 🌲を🕳️に切り替え
                    }
                }
        }
    }
    
    // 木の状態を保持する構造体
    struct TreeState {
        var isCut: Bool = false
        var isBeingCut: Bool = false // 🌲と🪓が完全に消えたか
        var isHole: Bool = false
        var showingHole: Bool = false
        var isSeedling: Bool = false
        var showingSeedling: Bool = false
        var wasSeedling: Bool = false // 元々🌱だったかどうか
        var isSliderControlled: Bool = false // Sliderで制御されるかどうか
        var isMulching: Bool = false
        var mulchingStage: Int = 0
        var showingMulching: Bool = false
        var mulchingOffset: CGFloat = 0
        var isFullyGrown: Bool = false  // 完全に成長した状態を追跡
        
        var flowerEmoji: String? = nil 
        var hasFlower: Bool = false 
        var bugEmoji: String? = nil
        var hasBug: Bool = false
        var birdEmoji: String? = nil 
        var hasBird: Bool = false 
        var animalEmoji: String? = nil // 動物の絵文字を保持
        var hasAnimal: Bool = false // 動物を表示済みかどうかのフラグ
    }
}
