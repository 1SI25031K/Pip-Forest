import SwiftUI

@main
struct Pip＆ForestApp: App {
    
    var body: some Scene {
        WindowGroup {
               OpeningView()
        }
    }
}
