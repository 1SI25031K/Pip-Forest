import SwiftUI
import AVFoundation

struct EndingView: View {
    @State private var synthesizer = AVSpeechSynthesizer() // speechSynthesizer を synthesizer
    @State private var isSpeaking = false // 読み上げ中かどうかを管理
    @State private var isEnding: Bool = true
    
    // メッセージを読み上げる関数
    func speakEnding(message: String) {
        let utterance = AVSpeechUtterance(string: message)
        
        utterance.pitchMultiplier = 1.5
        // 読み上げ速度を遅くする (例: 0.4倍)
        utterance.rate = AVSpeechUtteranceDefaultSpeechRate * 0.8 // デフォルトの速度の 0.7倍
        
        if let voice = AVSpeechSynthesisVoice(identifier: "com.apple.ttsbundle.Samantha-compact") {
            utterance.voice = voice
        } else {
            utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        }
        synthesizer.speak(utterance)
    }
    
    var body: some View {
        NavigationStack {
            ScrollView(.vertical){
                VStack{
                    Text("What a fantastic forest!")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .fontDesign(.serif)
                        .padding()
                        .padding(.horizontal, 20)
                        .padding(.top, 60)
                    Image("Pip")
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .cornerRadius(8)
                        .padding(.horizontal, 20)
                        .padding(.vertical)
                        .accessibilityLabel("A image of Pip, looks like a small white mouse with large ears, wearing a pointed blue wizard's hat with a gold band and a yellow bow tie. Pip stands on a white box in a lush green forest, holding a wooden wand with a sparkling star at the tip. The background is a blur of green foliage with glowing orbs of light.") // VoiceOverに画像の内容を説明するラベル
                    Text("Pip showed up, happy because you have created a funtastic forest! And said \"If activities like the ones you helped us with can go on in other forests, the world will be a better place than it is now!\"")
                        .font(.title)
                        .fontDesign(.serif)
                        .padding()
                        .background(Color.white.opacity(0.7))
                        .border(.black)
                        .padding(.horizontal, 20)
                        .padding()
                        .accessibilityLabel("Tap the button below to hear the story.")
                    Button(action: {
                        isSpeaking.toggle()
                        if isSpeaking {
                            speakEnding(message: "Pip showed up, happy because you have created a funtastic forest! And said \"If activities like the ones you helped us with can go on in other forests, the world will be a better place than it is now!\"")
                        } else {
                            synthesizer.stopSpeaking(at: .immediate) // 読み上げ停止処理を追加
                        }
                    }) {
                        Image(systemName: isSpeaking ? "speaker.slash.circle.fill" : "speaker.wave.2.circle.fill") // 読み上げ状態によってアイコンを変更
                            .font(.system(size: 50))
                            .symbolRenderingMode(.palette) // パレットモードを設定
                            .foregroundStyle(isSpeaking ? Color.red : Color.blue, .white.opacity(0.8))
                            .padding(.bottom, 60)
                            .accessibilityLabel(isSpeaking ? "Stop reading story" : "Read story aloud") // VoiceOver用ラベルを追加：読み上げ状態に応じてラベルを変更
                    }
                }
            }
            .ignoresSafeArea()
        } .navigationBarBackButtonHidden(true)
    }
}
